'use client';

import { useEffect, useRef, useState } from 'react';
import { loadDraft } from '@/lib/db';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import Link from 'next/link';

export default function BlueprintPage() {
  const [affirmation, setAffirmation] = useState<any>(null);
  const [visuals, setVisuals] = useState<any>(null);
  const [ready, setReady] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    Promise.all([loadDraft<any>('affirmation'), loadDraft<any>('visuals')]).then(([a, v]) => {
      setAffirmation(a);
      setVisuals(v);
      setReady(!!a && !!v);
    });
  }, []);

  const exportPNG = async () => {
    if (!cardRef.current) return;
    const canvas = await html2canvas(cardRef.current, { scale: 2 });
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url; a.download = 'blueprint.png'; a.click();
  };

  const exportPDF = async () => {
    if (!cardRef.current) return;
    const canvas = await html2canvas(cardRef.current, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'letter' });
    const margin = 40;
    const width = pdf.internal.pageSize.getWidth() - margin*2;
    const ratio = canvas.height / canvas.width;
    const height = width * ratio;
    pdf.addImage(imgData, 'PNG', margin, margin, width, height);
    pdf.save('blueprint.pdf');
  };

  if (!ready) {
    return <main className="card">Please complete the previous steps. <Link className="underline ml-2" href="/quiz">Start over</Link></main>;
  }

  return (
    <main className="space-y-6">
      <div className="card" ref={cardRef}>
        <div className="step mb-2">Your Personalized Manifestation Blueprint</div>
        <div className="text-3xl font-extrabold tracking-wide mb-4">{affirmation?.quote}</div>
        <div className="flex gap-2 mb-4">
          {visuals?.colors?.map((c:any)=> (
            <span key={c.hex} className="inline-flex items-center gap-2 border rounded-xl px-3 py-1">
              <span className="inline-block w-4 h-4 rounded" style={{background:c.hex}}></span>
              <span className="text-sm">{c.name} {c.hex}</span>
            </span>
          ))}
        </div>
        <div className="text-sm text-gray-600">Symbol: <b>{visuals?.symbol}</b></div>
        <div className="mt-6 text-xs text-gray-500">Practice: repeat your quote daily while visualizing these colors and symbol.</div>
      </div>

      <div className="card flex gap-3">
        <button className="btn btn-secondary" onClick={exportPNG}>Export PNG</button>
        <button className="btn btn-primary" onClick={exportPDF}>Export PDF</button>
        <Link className="btn btn-secondary" href="/b/demo">Sharable demo (placeholder)</Link>
      </div>
    </main>
  );
}
