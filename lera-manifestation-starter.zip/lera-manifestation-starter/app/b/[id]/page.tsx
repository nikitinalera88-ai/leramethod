export default function SharedView({ params }: { params: { id: string } }) {
  // In a real deployment with Supabase, this would fetch the blueprint by ID (and token).
  return (
    <main className="card">
      <div className="step">Sharable View (placeholder)</div>
      <p className="text-gray-700">Blueprint ID: <b>{params.id}</b></p>
      <p className="text-sm text-gray-500 mt-2">Hook up Supabase to serve real data.</p>
    </main>
  );
}
