import Link from 'next/link';

export default function Page() {
  return (
    <main className="card">
      <div className="step">Mindset & Intention · Steps 1–3</div>
      <h2 className="text-xl font-semibold mt-2 mb-4">Your Personalized Manifestation Blueprint</h2>
      <p className="text-gray-700 mb-6">
        We’ll uncover your core desire, transform it into a Structured Affirmation, and propose visuals
        (colors & symbols) to reinforce your practice.
      </p>
      <Link className="btn btn-primary" href="/quiz">Start</Link>
    </main>
  );
}
