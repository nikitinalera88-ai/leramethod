import { NextRequest, NextResponse } from 'next/server';
import { getClient } from '@/lib/supabase';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = getClient();
  if (!supabase) return NextResponse.json({ error: 'Supabase not configured' }, { status: 400 });
  const { data, error } = await supabase.from('blueprint').select('data').eq('id', params.id).single();
  if (error) return NextResponse.json({ error: error.message }, { status: 404 });
  return NextResponse.json(data?.data ?? {});
}
