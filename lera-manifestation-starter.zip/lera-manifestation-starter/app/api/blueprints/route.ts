import { NextRequest, NextResponse } from 'next/server';
import { getClient } from '@/lib/supabase';

export async function POST(req: NextRequest) {
  const supabase = getClient();
  if (!supabase) return NextResponse.json({ error: 'Supabase not configured' }, { status: 400 });
  const data = await req.json();
  const { data: inserted, error } = await supabase.from('blueprint').insert({ data }).select('id').single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  const id = inserted?.id;
  return NextResponse.json({ id, url: `/b/${id}` });
}
