'use client';

import { useEffect, useState } from 'react';
import { chooseColors, symbolChoices } from '@/lib/visuals';
import { loadDraft, saveDraft } from '@/lib/db';
import { useRouter } from 'next/navigation';

export default function VisualsPage() {
  const router = useRouter();
  const [quote, setQuote] = useState('');
  const [coreFeeling, setCoreFeeling] = useState('');
  const [colors, setColors] = useState<{name:string; hex:string}[]>([]);
  const [symbol, setSymbol] = useState<string>('');

  const symbols = symbolChoices();

  useEffect(() => {
    Promise.all([loadDraft<any>('quiz'), loadDraft<any>('affirmation')]).then(([q, a]) => {
      if (!q || !a) { router.replace('/quiz'); return; }
      setCoreFeeling(q.coreFeeling || '');
      setQuote(a.quote || '');
      const suggested = chooseColors(q.coreFeeling || '', a.quote || '');
      setColors(suggested);
      setSymbol(symbols[0]?.key || 'shield');
    });
  }, [router]);

  const toggleColor = (hex: string) => {
    const exists = colors.find(c => c.hex === hex);
    if (exists) setColors(colors.filter(c => c.hex !== hex));
    else if (colors.length < 3) {
      const all = chooseColors(coreFeeling, quote);
      const item = all.find(c => c.hex === hex);
      if (item) setColors([...colors, item]);
    }
  };

  const proceed = async () => {
    await saveDraft('visuals', { colors, symbol });
    router.push('/blueprint');
  };

  const all = chooseColors(coreFeeling, quote);

  return (
    <main className="card space-y-6">
      <div className="step">Step 3 — Visual Translation</div>

      <div className="text-sm text-gray-500">Select up to three colors that reinforce your quote.</div>
      <div className="flex gap-3 flex-wrap">
        {all.map(c => (
          <button key={c.hex} onClick={()=>toggleColor(c.hex)} className={`rounded-xl px-3 py-2 border ${colors.find(x=>x.hex===c.hex)?'border-gray-900':'border-gray-300'}`}>
            <span className="inline-block w-5 h-5 rounded-full mr-2 align-middle" style={{background:c.hex}}></span>
            {c.name} {c.hex}
          </button>
        ))}
      </div>

      <div>
        <label className="label">Reinforcing Symbol</label>
        <select className="input" value={symbol} onChange={e=>setSymbol(e.target.value)}>
          {symbols.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
        </select>
      </div>

      <div className="flex gap-3">
        <button className="btn btn-primary" onClick={proceed}>Continue</button>
      </div>
    </main>
  );
}
