import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'The Lera Method™ — Manifestation Blueprint',
  description: 'Quiz → Structured Affirmation → Visuals → Blueprint',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="container py-8">
          <header className="mb-6">
            <h1 className="text-2xl md:text-3xl font-semibold">The Lera Method™</h1>
            <p className="text-gray-600">Your Personalized Manifestation Blueprint</p>
          </header>
          {children}
          <footer className="mt-12 text-sm text-gray-500">© {new Date().getFullYear()} The Lera Method™</footer>
        </div>
      </body>
    </html>
  );
}
