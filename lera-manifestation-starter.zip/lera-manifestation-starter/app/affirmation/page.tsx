'use client';

import { useEffect, useState } from 'react';
import { loadDraft, saveDraft } from '@/lib/db';
import { buildAffirmation } from '@/lib/affirmation';
import { useRouter } from 'next/navigation';

type QuizState = {
  refinedDesire: string;
  coreFeeling: string;
  coreFeelingCustom?: string;
};

export default function AffirmationPage() {
  const router = useRouter();
  const [refined, setRefined] = useState('');
  const [quote, setQuote] = useState('');
  const [issues, setIssues] = useState<string[]>([]);

  useEffect(() => {
    loadDraft<any>('quiz').then(q => {
      if (!q) { router.replace('/quiz'); return; }
      setRefined(q.refinedDesire || '');
      const r = buildAffirmation(q.refinedDesire || '');
      setQuote(r.quote); setIssues(r.issues);
      saveDraft('affirmation', r);
    });
  }, [router]);

  const fixIssues = () => {
    const r = buildAffirmation(refined);
    setQuote(r.quote); setIssues(r.issues);
    saveDraft('affirmation', r);
  };

  const proceed = () => router.push('/visuals');

  return (
    <main className="card space-y-6">
      <div className="step">Step 2 — Structured Affirmation</div>

      <div>
        <label className="label">Refined Desire</label>
        <textarea className="input" rows={3} value={refined} onChange={e=>setRefined(e.target.value)} />
        <p className="hint">We’ll transform this into a present‑tense, positive, personalized quote.</p>
      </div>

      <div className="border rounded-2xl p-4">
        <div className="text-sm text-gray-500 mb-2">Your Personalized Manifestation Quote</div>
        <div className="text-2xl font-bold tracking-wide">{quote || '...'}</div>
      </div>

      {issues.length > 0 && (
        <div className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-3">
          Needs fixes: {issues.join(', ')} <button className="ml-2 underline" onClick={fixIssues}>Auto‑fix</button>
        </div>
      )}

      <div className="flex gap-3">
        <button className="btn btn-secondary" onClick={fixIssues}>Regenerate</button>
        <button className="btn btn-primary" onClick={proceed}>Continue</button>
      </div>
    </main>
  );
}
