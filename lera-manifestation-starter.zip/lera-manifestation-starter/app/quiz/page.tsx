'use client';

import { useEffect, useState } from 'react';
import { saveDraft, loadDraft } from '@/lib/db';
import { useRouter } from 'next/navigation';

type QuizState = {
  surfaceDesire: string;
  why1: string;
  why2: string;
  coreFeeling: string;
  coreFeelingCustom?: string;
  futureState: string;
  refinedDesire: string;
};

const feelings = ['freedom', 'security', 'peace', 'confidence', 'connection', 'custom'] as const;

export default function QuizPage() {
  const router = useRouter();
  const [s, setS] = useState<QuizState>({
    surfaceDesire: '', why1: '', why2: '', coreFeeling: '', futureState: '', refinedDesire: ''
  });

  useEffect(() => {
    loadDraft<QuizState>('quiz').then(v => v && setS(v));
  }, []);

  useEffect(() => { saveDraft('quiz', s); }, [s]);

  const set = (k: keyof QuizState) => (e: any) => setS({ ...s, [k]: e.target.value });

  const proceed = () => {
    // quick validations
    if (!s.surfaceDesire || !s.why1 || !s.coreFeeling || !s.futureState || !s.refinedDesire) {
      alert('Please complete the required fields.');
      return;
    }
    router.push('/affirmation');
  };

  return (
    <main className="card space-y-5">
      <div className="step">Step 1 — Deep Desire Interrogation</div>
      <div>
        <label className="label">Your immediate goal (Surface Desire)</label>
        <input className="input" value={s.surfaceDesire} onChange={set('surfaceDesire')} placeholder="e.g., I want money" />
        <p className="hint">Surface goals often lack clarity. We'll refine this shortly.</p>
      </div>

      <div>
        <label className="label">Why do you want this? (Why #1)</label>
        <textarea className="input" rows={3} value={s.why1} onChange={set('why1')} />
      </div>

      <div>
        <label className="label">Follow-up: Why do you want that? (Why #2)</label>
        <textarea className="input" rows={3} value={s.why2} onChange={set('why2')} />
      </div>

      <div>
        <label className="label">What do you truly desire at your core? (Core Feeling)</label>
        <div className="grid grid-cols-2 gap-2">
          {feelings.map(f => (
            <label key={f} className={`border rounded-xl px-3 py-2 cursor-pointer ${s.coreFeeling===f?'border-gray-900':'border-gray-300'}`}>
              <input type="radio" name="cf" className="mr-2" checked={s.coreFeeling===f} onChange={() => setS({...s, coreFeeling: f})} /> {f}
            </label>
          ))}
        </div>
        {s.coreFeeling === 'custom' && (
          <input className="input mt-2" placeholder="Your core feeling" value={s.coreFeelingCustom||''} onChange={set('coreFeelingCustom')} />
        )}
      </div>

      <div>
        <label className="label">What will your life look like then? (1 sentence future-state)</label>
        <input className="input" value={s.futureState} onChange={set('futureState')} placeholder="e.g., I create without stress" />
      </div>

      <div>
        <label className="label">Refine your goal (Refined Desire)</label>
        <input className="input" value={s.refinedDesire} onChange={set('refinedDesire')} placeholder="I want financial security so I can create without stress" />
      </div>

      <div className="flex gap-3">
        <button className="btn btn-secondary" onClick={() => { setS({surfaceDesire:'',why1:'',why2:'',coreFeeling:'',futureState:'',refinedDesire:''}); }}>Clear</button>
        <button className="btn btn-primary" onClick={proceed}>Continue</button>
      </div>
    </main>
  );
}
