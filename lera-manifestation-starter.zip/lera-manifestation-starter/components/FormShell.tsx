'use client';
import Link from 'next/link';

export default function FormShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="card">
      {children}
      <div className="mt-6 text-xs text-gray-500 flex items-center justify-between">
        <Link className="underline" href="/">Home</Link>
        <span>Local-only by default • No login required</span>
      </div>
    </div>
  );
}
