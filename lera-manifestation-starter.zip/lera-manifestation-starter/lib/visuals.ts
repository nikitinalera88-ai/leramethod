import mapping from '@/content/visuals.json';

export type Color = { name: string; hex: string };
export type Symbol = { key: string; label: string };

export function chooseColors(coreFeeling: string, quote: string): Color[] {
  const colors = mapping.colors as Record<string, Color>;
  const out: Color[] = [];

  const add = (c?: Color) => {
    if (!c) return;
    if (out.find(x => x.hex === c.hex)) return;
    if (out.length < 3) out.push(c);
  };

  // Map core feeling
  const cf = coreFeeling.toLowerCase();
  if (/(security|safe|ground)/.test(cf)) add(colors.security_grounding);
  if (/(peace|calm)/.test(cf)) add(colors.calm_peace);
  if (/(freedom|success|wealth)/.test(cf)) add(colors.wealth_success);
  if (/(confidence|energy|passion|power)/.test(cf)) add(colors.energy_passion);
  if (/(clarity|focus)/.test(cf)) add(colors.clarity_focus);

  // Keywords in quote
  const q = quote.toLowerCase();
  if (/success|wealth|abundance|prosper/.test(q)) add(colors.wealth_success);
  if (/calm|peace|serene|still/.test(q)) add(colors.calm_peace);
  if (/energy|passion|ignite|drive|discipline/.test(q)) add(colors.energy_passion);
  if (/secure|stability|root|ground/.test(q)) add(colors.security_grounding);
  if (/clear|focus|clarity|aware/.test(q)) add(colors.clarity_focus);

  // Ensure at least one
  if (out.length === 0) add(colors.calm_peace);

  return out.slice(0,3);
}

export function symbolChoices(): Symbol[] {
  // @ts-ignore
  return mapping.symbols as Symbol[];
}
