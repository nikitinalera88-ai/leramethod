export type AffirmationResult = { quote: string; issues: string[] };

export function buildAffirmation(refined: string): AffirmationResult {
  const issues: string[] = [];
  let text = (refined ?? '').trim();

  // 1) Personalized
  if (!/^\s*(I\s+am|My)\b/i.test(text)) {
    text = `I am ${text.replace(/^to\s+/i, '').replace(/^I\s+want\s+to\s+/i, '')}`;
  }

  // 2) Positive
  const negations = /(don\'t|do not|not|stop|no longer)/i;
  if (negations.test(text)) {
    issues.push('containsNegation');
    text = text
      .replace(/I\s+am\s+not\s+/gi, 'I am ')
      .replace(/I\s+don\'t\s+want\s+/gi, 'I want ')
      .replace(/no\s+longer\s+/gi, '')
      .replace(/\bnot\b\s*/gi, '');
  }

  // 3) Present tense
  if (/(will|going to|someday)/i.test(text)) {
    issues.push('notPresentTense');
    text = text.replace(/\bwill\b/gi, '').replace(/\bgoing to\b/gi, '').replace(/\bsomeday\b/gi, '');
  }

  const quote = text.toUpperCase().replace(/\.+$/, '');
  return { quote, issues };
}
