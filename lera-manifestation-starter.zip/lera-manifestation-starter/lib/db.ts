import localforage from 'localforage';

export const store = localforage.createInstance({ name: 'lera_manifestation' });

export async function saveDraft(key: string, data: unknown) {
  await store.setItem(key, data);
}
export async function loadDraft<T>(key: string): Promise<T | null> {
  const v = await store.getItem<T>(key);
  return v ?? null;
}
export async function clearAll() {
  await store.clear();
}
