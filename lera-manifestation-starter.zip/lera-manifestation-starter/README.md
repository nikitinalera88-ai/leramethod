# The Lera Method™ — Manifestation Blueprint (MVP Starter)

This is a minimal Next.js App Router project that implements Steps 1–3 of The Lera Method™:
- Quiz → Deep Desire Interrogation
- Structured Affirmation generation (Personalized, Positive, Present‑tense)
- Visual Translation (colors & symbol)
- Export to PNG/PDF

## Quick start

```bash
pnpm i
pnpm dev
```

Open http://localhost:3000 and click **Start**.

## Deploy (Vercel)

1. Push to GitHub and import the repo in Vercel.
2. (Optional) For cloud share links, create a Supabase project and a `blueprint` table:

```sql
create table if not exists blueprint (
  id uuid primary key default gen_random_uuid(),
  data jsonb not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz generated always as (created_at + interval '30 days') stored
);
```

3. Set env vars in Vercel:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

If you skip Supabase, the app still works fully in **local-only** mode and export functions (PNG/PDF) work.

## Notes

- All data is saved locally in IndexedDB (via localforage) unless you explicitly hit the cloud save endpoint.
- Color mappings and symbol catalog live in `content/visuals.json`.
- Affirmation rule engine lives in `lib/affirmation.ts`.
- You can customize styles in `app/globals.css`.

© 2025 The Lera Method™
